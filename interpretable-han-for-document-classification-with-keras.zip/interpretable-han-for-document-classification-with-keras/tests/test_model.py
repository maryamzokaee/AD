def test_sample_len(df_review):
    assert len(df_review) == 200
